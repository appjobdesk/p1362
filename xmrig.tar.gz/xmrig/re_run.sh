#!/bin/bash

# Cek dan bersihkan sesi screen yang lama
echo "Cek dan bersihkan sesi screen yang lama..."
screen -ls
screen -wipe

# Loop tak terbatas untuk menjalankan mining dengan jeda
echo "Memulai loop mining dengan jeda..."
while true; do
    # Jalankan mining di screen 'github'
    echo "Memulai mining di screen 'github'..."
    screen -S github -dm ./xmrig --config=config.json --threads=3
    echo "Mining berjalan..."
    
    # Mining selama 58 menit
    sleep 3480  # 58 menit dalam detik
    
    # Hentikan proses mining
    echo "Menghentikan mining untuk jeda..."
    screen -S github -X quit
    
    # Jeda selama 5 menit
    echo "Jeda selama 5 menit..."
    sleep 300  # 5 menit dalam detik

done
